ALTER TABLE buses
    DROP COLUMN Ac_Available;
